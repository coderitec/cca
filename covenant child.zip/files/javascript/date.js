let month = ''

switch(new Date().getMonth()){
    case 0:
        month = 'January'
        break
    case 1:
        month = 'February'
        break
    case 2:
        month = 'March'
        break
    case 3:
        month = 'April'
        break
    case 4:
        month = 'May'
        break
    case 5:
        month = 'June'
        break
    case 6:
        month = 'July'
        break
    case 7:
        month = 'August'
        break
    case 8:
        month = 'September'
        break
    case 9:
        month = 'October'
        break
    case 10:
        month = 'November'
        break
    default:
        month = 'December'        
}

const para = document.getElementById('date')
const date = `${new Date().getDate()} ${month}, ${new Date().getFullYear()}`
para.textContent = date