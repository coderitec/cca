let num1 = 40
const num2 = 20
let num3
const num4 = 66
num3 = 88

let name1 = 'franc'
let name2 = "enemuo"
let name3 = `chiname`
let perculiar = "mercy johnson"
let name4 = perculiar
let state1 = `${perculiar} was born in 1995, therefore he is ${new Date().getFullYear() - 2005} years old`



num1 =num1 + num2

console.log(state1)